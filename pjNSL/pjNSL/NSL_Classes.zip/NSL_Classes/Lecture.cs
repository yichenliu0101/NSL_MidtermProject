﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1.NSL_Classes
{
    public class Lecture
    {
        public int LectureId { get; set; }
        public string TeacherName { get; set; }
        public string Tag { get; set; }
        public string LectureName { get; set; }
        public decimal Price { get; set; }
    }
}
